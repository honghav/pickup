<?php

    include "connection.php";

    session_start();

   $seller_name =  $_SESSION['seller_name'];
   $seller_id =  $_SESSION['seller_id'];
    $id = $_GET['id'];
    

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<table class="table" style="width: 1500px; margin: 100px; height: 150px;">
        <thead class="table-dark" >
        <tr>
       <th>Number order</th>
       <th>Name</th>
       <th>Price</th>
       <th>total price</th>
       <th>QTY</th>
       <th>Image</th>
       <th>customer id</th>
       <th>customer name</th>

       <th>Delete</th>
     </tr>
        </thead>
        <tbody>
        <?php
           $sql_order_items = "SELECT * FROM order_items 
           INNER JOIN products ON products.product_id = order_items.product_id 
           INNER JOIN customer ON customer.customer_id = order_items.customer_id
            INNER JOIN category ON category.category_id = products.category_id 
            
            WHERE category.seller_id = $seller_id and order_items.order_number = $id; ";
            $result=$conn->query($sql_order_items);
             if ($result->num_rows > 0) {
                while( $row = $result->fetch_assoc()){ ?>
            <tr>
                <th><?php echo $row['order_number']	; ?></th>
                <th><?php echo$row['product_name']; ?></th>
                <th>$<?php echo $row['product_price']	; ?></th>
                <th>$<?php echo $row['order_price']	; ?></th>
                <th><?php echo $row['order_qty']	; ?></th>
                <th><img src="<?php echo$row['product_image'];  ?>" alt=""  width="50px" height="50px" ></th>
                <th><?php echo $row['customer_id']	; ?></th>
                <th><?php echo $row['username'] ?></th>
            </tr>
              <?php
                }
            }
            ?>
        </tbody>
    </table>
</body>
</html>