<?php
    $conn = mysqli_connect("localhost", "root" , "" , "pickup");
    if($conn -> connect_error){
        //echo "false";
        die('Connection Failed!');
    }else{
        echo"hello";
    } ?>