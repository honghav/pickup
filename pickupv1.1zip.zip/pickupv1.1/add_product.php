<?php
    include "connection.php";
    session_start();
    $seller_name =  $_SESSION['seller_name'];
   $seller_id =  $_SESSION['seller_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Form - GET Method</title>
</head>
<body>

    <h2>Welcome too <?php echo$seller_name; ?></h2>
    <button><a href="shop_dashbord.php">go back</a></button>
    <form  method="get">
        <label for="text1">Name Of Product:</label>
        <input type="text" id="text1" name="name"><br><br>

        <label for="text2">Price Of Product:</label>
        <input type="text" id="text2" name="price"><br><br>

        <label for="text3">Detail Of Product:</label>
        <input type="text" id="text3" name="detail"><br><br>

        <label for="text4">Image Of Product:</label>
        <input type="text" id="text4" name="image"><br><br>

        <label for="text4">QTY Of Product:</label>
        <input type="number" id="text4" name="qty"><br><br>

        <label for="option">Chosse Category Of Product:</label>
        <select id="option" name="category">
        <?php 
            $sql_category = " SELECT * FROM `category` WHERE seller_id = $seller_id; ";
            $result=$conn->query($sql_category);
            if ($result->num_rows > 0) {
               while( $row = $result->fetch_assoc()){ ?>
       

        <option value="<?php echo $row['category_id'] ;?>"><?php echo $row['category_name'] ;?></option>
            
        <?php
            echo $row['category_name'] ;
                }
            }
        ?>
        </select><br><br>
        <input type="submit" value="Submit " name ="submit">
    </form>
</body>
</html>
<?php
         if(!empty(isset($_GET['submit']))){
            $category  = $_GET["category"];
            $name = $_GET['name'];
            $price = $_GET['price'];
            $detail = $_GET['detail'];
            $image = $_GET['image'];
            $qty = $_GET['qty'];
            if(!empty(trim($name))  && !empty(trim($price))  && !empty(trim($image)) && !empty(trim($detail))){ 
                $input = "INSERT INTO `products`( `product_name`, `product_price`, `product_image`, `product_qty`, `category_id`) 
                VALUES ('$name','$price','$image','$qty','$category')";
                 if ($conn->query($input) === TRUE) {
                    echo "<script>alert('already');window.location='dashbord_seller.php'</script>";
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }else{
                echo"NOO";
             }
         }

?>

    
 