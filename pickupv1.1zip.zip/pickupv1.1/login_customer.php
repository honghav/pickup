<?php

    include "connection.php";
    if(isset($_POST['submit'])){
        $name = $_POST['name'];
        // echo $name;
        if(!empty($name)){
            echo $name;
            $sql = "SELECT * FROM `customer` WHERE username='$name' ";
            $result = $conn->query($sql);
            if(mysqli_num_rows($result) > 0){
                $row = mysqli_fetch_assoc($result);
            }
            else{
                echo "<script>alert('login NO already');window.location='login_customer.php'</script>";            }
    
        } 
    }

session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
   
   
    // Retrieve username and password from form
    $name = $_POST['name'];
   

    // SQL query to check if the name and password match
    $sql = "SELECT * FROM `customer` WHERE username='$name' ";
    $result = $conn->query($sql);
    if ($result->num_rows == 1) {
        $row = mysqli_fetch_assoc( $result );
        // Login successful, start session
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $name;
        $_SESSION['customer_id'] = $row['customer_id'];

        echo "<script>alert('login already');window.location='homepage.php'</script>";
    } else {
        // Login failed
        echo "Invalid username or password";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<div class="login">
        <form action="login_customer.php" method="post">
        <input type="text" name="name" placeholder="name">
        <button name="submit">go back</button>
        </form>
    </div>
</body>
</html>