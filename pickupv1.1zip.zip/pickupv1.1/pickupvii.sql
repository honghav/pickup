create database pickup;

use pickup;

create table customer (
	customer_id int auto_increment primary key not null ,
    username varchar(50) not null,
    user_profile varchar(255) null,
   number_phone int not null);
   
   select * from customer;
   
create table seller (
	seller_id int auto_increment primary key not null ,
    seller_name varchar(100) unique not null,
    seller_address varchar(255) not null, 
    seller_type varchar(50)  not null,
    seller_image varchar(255) null,
    seller_contact int null );
    
       select * from seller;

create table category(
	category_id int primary key auto_increment not null ,
    category_name varchar(100) not null ,
    category_image varchar(255) null ,
    seller_id int not null,
    foreign key (seller_id) references seller(seller_id)
    );
    
       select * from category;
    
CREATE TABLE products (
    product_id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    product_name VARCHAR(150) NOT NULL,
    product_price INT NOT NULL, 
    product_image VARCHAR(255) NULL,
    product_qty INT NOT NULL, 
    category_id INT NOT NULL,
    FOREIGN KEY (category_id) REFERENCES category(category_id)
);

    select * from products;
    
    SELECT * FROM products inner join category on  category.category_id = products.category_id where seller_id = 1 ; 
    
    SELECT COUNT(*)  FROM products inner join category on category.category_id = products.category_id where category.seller_id = 2 ;
 
