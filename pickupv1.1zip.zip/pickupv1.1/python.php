<?php
    include "connection.php";
    
                    ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>

           
    </style>
</head>
<body>

<main>
       <?php
        $sql_product = " SELECT * FROM category inner join products on category.category_id = products.category_id inner join seller on category.seller_id = seller.seller_id;";
        $result_sql_product = $conn->query($sql_product);
        if ($result_sql_product->num_rows > 0) {
            while ($row = $result_sql_product->fetch_assoc()) {
                ?>
       <div class="card">
           <div class="image">
               <img src="<?php echo $row["product_image"]; ?>" alt="">
           </div>
           <div class="caption">
               <p class="rate">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
               </p>
               <p class="product_name"><?php  echo $row["product_name"];  ?></p>
               <p class="price"><b>$<?php echo $row["product_price"]; ?></b></p>
               <p class="discount"><b><del>$<?php echo $row["seller_name"]; ?></del></b></p>
           </div>
           <button class="add" data-id="<?php echo $row["product_id"];  ?>">Add to cart</button>
       </div>
       <?php
            }
          }
     ?>
   </main>
        
    
</body>
</html>