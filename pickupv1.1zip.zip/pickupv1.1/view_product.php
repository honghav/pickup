<?php
    include "connection.php";
    session_start();
    $username= $_SESSION['username'] ;
    $cus_id =  $_SESSION['customer_id'];
    $pro_id = $_GET['id'];
    
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>

            *{
                padding: 0;
                margin: 0;
                box-sizing: border-box;
                font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
                color: black;
            }

            html{
                font-size: 62.5%;
            }

            main{
                max-width: 1500px;
                width: 95%;
                margin: 30px auto;
                display: flex;
                flex-wrap: wrap;
                justify-content: space-between;
                margin: auto;
            }

            main .card{
                max-width: 300px;
                flex: 1 1 210px;
                text-align: center;
                height: 420px;
                border: 1px solid lightgray;
                margin: 20px;
            }

            main .card .image{
                height: 50%;
                margin-bottom: 20px;
            }

            main .card .image img{
                width: 100%;
                height: 100%;
                object-fit: cover;
            }

            main .card .caption{
                padding-left: 1em;
                text-align: left;
                line-height: 3em;
                height: 25%;
            }

            main .card .caption p{
                font-size: 1.5rem;
            }

            del{
                text-decoration: line-through;
            }

            main .card .caption .rate{
                display: flex;
            }

            main .card .caption .rate i{
                color: gold;
                margin-left: 2px;
            }

            main .card a{
                width: 50%;
            }

            button{
                border: 2px solid black;
                padding: 1em;
                width: 200px;
                cursor: pointer;
                margin-top: 2em;
                font-weight: bold;
                position: relative;
            }

            button:before{
                content: "";
                position: absolute;
                top: 0;
                left: 0;
                bottom: 0;
                width: 0;
                background-color: black;
                transition: all .5s;
                margin: 0;
            }

            button::after{
                content: "";
                position: absolute;
                top: 0;
                right: 0;
                bottom: 0;
                width: 0;
                background-color: black;
                transition: all .5s;
            }

            button:hover::before{
                width: 30%;
            }

            button:hover::after{
                width: 30%;
            }

    </style>
</head>
<body>
    
<main>
       <?php
        $sql_product = " SELECT * FROM category inner join products on category.category_id = products.category_id inner join seller on category.seller_id = seller.seller_id WHERE product_id = $pro_id;";
        $result_sql_product = $conn->query($sql_product);
        if ($result_sql_product->num_rows > 0) {
            while ($row = $result_sql_product->fetch_assoc()) {
                ?>
       <div class="card">
           <div class="image">
               <img src="<?php echo $row["product_image"]; ?>" alt="">
           </div>
           <div class="caption">
               <p class="rate">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
               </p>
               <p class="product_name"><?php  echo $row["product_name"];  ?></p>
               <p class="price"><b>$<?php echo $row["product_price"]; ?></b></p>
               <p class="discount"><b><del>$<?php echo $row["seller_name"]; ?></del></b></p>
           </div>
       </div>
       <?php
       $price=$row['product_price'];
            }
          }
     ?>
   </main>
   <form method ="post">
          <input type="number" name="qty">
          <button class="add" name="submit" >Add to cart</button>
          </form>
</body>
</html>
<?php
    if(isset($_POST['submit'])){
        $qty = $_POST['qty'];
        $randomNumber = rand(1000, 9999);
        $price_of_cart = $price * $qty;
        $sql_insert_cart = "INSERT INTO `carts`( `cart_number`, `product_id`, `cart_qty`, `cart_price`, `customer_id`) 
         VALUES ('$randomNumber','$pro_id','$qty','$price_of_cart','$cus_id')";
          if ($conn->query($sql_insert_cart) === TRUE) {
            echo "<script>alert('already');window.location='add_cart.php'</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

 
        

        
    }
?>
