
<?php
    include "connection.php";
   session_start();

   $seller_name =  $_SESSION['seller_name'];
   $seller_id =  $_SESSION['seller_id'];

    ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">

    <title>Document</title>
</head>
<body>
    <button><a href="loing_seller.php">logout</a></button>
    <div class="navbar">
        <div class="sitting">
            <img src="image/sitting.png" alt="" height="75px" width="75px">
        </div>
        <div class="nav_right"><?php
        $logo_seller = "SELECT seller_image from seller where seller_id = '$seller_id';";
        $result_logo_seller=$conn->query($logo_seller);
                            if ($result_logo_seller) {
                                // Fetch the result
                                $row = $result_logo_seller->fetch_assoc();
                                if ($row) {
                                    echo  "<img src='" .$row['seller_image']."' alt='none' height='75px' width='250px' >";
                                } else {
                                    echo "No data found.";
                                }
                                // Free result_logo_seller set
                                $result_logo_seller->free();
                            } else {
                                echo "Error executing query: " . $conn->error;
                            }
 
   ?>
            
        </div>

        <div class="search">
            
                <div class="button_page">
                    <img src="image/icon2.png" alt="" width="50px" height="50px">
                    <div class="form_search" >
                        <form> 
                            <input type="text" placeholder="Seacrh......">
                        </form>
                    
                </div>
            </div>
        </div>

        <div class="all_button_nav_left">
            <div class="nav_left">
                <div class="button_page">
                    <img src="image/icon1.png" alt="" width="50px" height="50px">
                    <div class="text_button" >
                        <p>Home</p>
                    </div>
                </div>
            </div>
           
            <div class="nav_left">
                <div class="button_page">
                    <img src="image/nav1.png" alt="" width="50px" height="50px">
                    <div class="text_button" >
                        <p>Wellat</p>
                    </div>
                </div>
            </div>
    
            <div class="nav_left">
                <div class="button_page">
                    <img src="image/nav2.png" alt="" width="50px" height="50px">
                    <div class="text_button" >
                        <p>History</p>
                    </div>
                </div>
            </div>

            <div class="nav_left">
                <div class="button_page">
                    <img src="image/profile.png" alt="" width="50px" height="50px">
                    <div class="text_button" >
                        <p>Profile</p>
                    </div>
                </div>
            </div>

        </div>

    </div>

    <h1><?php echo $seller_name;?></h1>
    <div class="imfortion_data " style="display: flex; margin: 100px;">
        <div class="datai" style="background-color: aquamarine; width: 400px; height: 200px; border-radius: 35px; display: flex; align-items: center; justify-content: center; margin: 10px 10px  10px 10px;"  >      
            <img src="image/category_icon.png" alt="" width="50px" height="50px">
            <p style="font-size: 44px;">Product:<span> <?php $count_product ="SELECT COUNT(*) AS total_items  FROM category where category.seller_id = '$seller_id' ";
                                $result_count_product=$conn->query($count_product);
                            if ($result_count_product) {
                                // Fetch the result
                                $row = $result_count_product->fetch_assoc();
                                if ($row) {
                                    echo  $row['total_items'];
                                } else {
                                    echo "No data found.";
                                }
                                // Free result_count_product set
                                $result_count_product->free();
                            } else {
                                echo "Error executing query: " . $conn->error;
                            }
            ?> </span> </p>
            </div>

        <div class="datai" style="background-color: aquamarine; width: 400px; height: 200px; border-radius: 35px; display: flex; align-items: center; justify-content: center; margin: 10px 10px  10px 10px;"  >
            <img src="image/product_icon.png" alt="" width="50px" height="50px">
            <p style="font-size: 44px;">Product:<span> <?php $count_product ="SELECT COUNT(*) AS total_items  FROM products inner join category on category.category_id = products.category_id where category.seller_id = '$seller_id' ";
                        $result_count_product=$conn->query($count_product);
                        if ($result_count_product) {
                            // Fetch the result
                            $row = $result_count_product->fetch_assoc();
                            if ($row) {
                                echo  $row['total_items'];
                            } else {
                                echo "No data found.";
                            }
                            // Free result_count_product set
                            $result_count_product->free();
                        } else {
                            echo "Error executing query: " . $conn->error;
                        }
                        ?> </span> </p>
        </div>

        <div class="datai" style="background-color: aquamarine; width: 400px; height: 200px; border-radius: 35px; display: flex; align-items: center; justify-content: center; margin: 10px 10px  10px 10px;"  >
            <img src="image/product_icon.png" alt="" width="50px" height="50px">
            <p style="font-size: 44px;">order: 100 </p>
        </div>
    </div>

    <div class="button">
        <button type="button" class="btn btn-primary"><a href="add_product.php">Add Product</a></button>
        <button type="button" class="btn btn-primary"><a href="add_cetegory.php">Add Category</a></button>
    </div>
    
    <table class="table" style="width: 1500px; margin: 100px; height: 150px;">
        <thead class="table-dark" >
          <tr>
            <th>No</th>
            <th>Number Order</th>
            <th>Price</th>
            <th>Items</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
        <?php
            $sql_select_order = "SELECT * FROM `orders`  ";
            $result=$conn->query($sql_select_order);
             if ($result->num_rows > 0) {
                while( $row = $result->fetch_assoc()){ ?>
            <tr>
                <th><?php echo $row['order_id'] ?></th>
                <th><?php echo $row['order_number'] ?></th>
                <th><?php echo $row['order_price_total'] ?>$</th>
                <th><a href="item_view.php?id=<?php echo $row['order_number'] ?>">VIEW</a></th>
                <th><img src="image/edit_icon.png" alt=""  width="50px" height="50px"></th>
                <th><img src="image/delete_icon.png" alt=""  width="50px" height="50px"></th>
              </tr>
              <?php
                }
            }
            ?>
        </tbody>
    </table>

    <table class="table" style="width: 1500px; margin: 100px; height: 150px;">
        <thead class="table-dark" >
          <tr>
            <th>No</th>
            <th>Name</th>
            <th>Image</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead> 
        <tbody>
        <?php
            $sql_category = " SELECT * FROM `category` WHERE seller_id = $seller_id; ";
            $result=$conn->query($sql_category);
             if ($result->num_rows > 0) {
                while( $row = $result->fetch_assoc()){ ?>
        <tr>
                <th><?php echo $row['category_id'];?></th>
                <th><?php echo $row['category_name'];?></th>
                <th><img src="<?php echo $row['category_image'];?>" alt="" width="50px" height="50px"></th>
                <th><img src="image/edit_icon.png" alt=""  width="50px" height="50px"></th>
                <th><img src="image/delete_icon.png" alt=""  width="50px" height="50px"></th>
              </tr>
              <?php
                }
            }
            ?>
        </tbody>

    </table>

    
    <table class="table" style="width: 1500px; margin: 100px; height: 150px;">
        <thead class="table-dark" >
          <tr>
            <th>No</th>
            <th>Name</th>
            <th>Price</th>
            <th>Category</th>
            <th>QTY</th>
            <th>Image</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
        <?php
            $sql_product = "SELECT * FROM products 
            inner join category on  category.category_id = products.category_id 
            where seller_id = $seller_id ; ";
            $result=$conn->query($sql_product);
             if ($result->num_rows > 0) {
                while( $row = $result->fetch_assoc()){ ?>
            <tr>
                <th><?php echo $row['product_id'] ?></th>
                <th><?php echo $row['product_name'] ?></th>
                <th><?php echo $row['product_price'] ?>$</th>
                <th><?php echo $row['category_id'] ?></th>
                <th><?php echo $row['product_qty'] ?></th>
                <th><img src="<?php echo $row['product_image'] ?>" alt="" width="50px" height="50px"></th>
                <th><img src="image/edit_icon.png" alt=""  width="50px" height="50px"></th>
                <th><img src="image/delete_icon.png" alt=""  width="50px" height="50px"></th>
              </tr>
              <?php
                }
            }
            ?>
        </tbody>
    </table>
      
    
</body>
</html>