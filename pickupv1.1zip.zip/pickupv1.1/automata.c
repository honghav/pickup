#include <stdio.h>
#include <stdbool.h>
#include <string.h>

// Define the maximum size for the DFA
#define MAX_STATES 100
#define MAX_SYMBOLS 10

typedef struct {
    int transitionTable[MAX_STATES][MAX_SYMBOLS];
    int numStates;
    int numSymbols;
    int startState;
    bool finalStates[MAX_STATES];
} DFA;

// Initialize the DFA by taking input from the user
void initializeDFA(DFA *dfa) {
    printf("Enter the number of states: ");
    scanf("%d", &dfa->numStates);

    printf("Enter the number of input symbols: ");
    scanf("%d", &dfa->numSymbols);

    printf("Enter the transition table (state transitions for each symbol):\n");
    for (int i = 0; i < dfa->numStates; i++) {
        for (int j = 0; j < dfa->numSymbols; j++) {
            printf("From state %d, on input %d -> ", i, j);
            scanf("%d", &dfa->transitionTable[i][j]);
        }
    }

    printf("Enter the start state: ");
    scanf("%d", &dfa->startState);

    printf("Enter the final states (1 for final, 0 for non-final):\n");
    for (int i = 0; i < dfa->numStates; i++) {
        int isFinal;
        printf("Is state %d a final state? (1/0): ", i);
        scanf("%d", &isFinal);
        dfa->finalStates[i] = (isFinal == 1);
    }
}

// Check if the input string is accepted by the DFA
bool isAcceptedByDFA(DFA *dfa, const char *input) {
    int currentState = dfa->startState;

    for (int i = 0; i < strlen(input); i++) {
        int symbol = input[i] - '0'; // Assuming input symbols are '0' to 'numSymbols-1'
        if (symbol < 0 || symbol >= dfa->numSymbols) {
            return false; // Invalid symbol
        }
        currentState = dfa->transitionTable[currentState][symbol];
    }

    return dfa->finalStates[currentState];
}

int main() {
    DFA dfa;
    initializeDFA(&dfa);

    char input[100];
    printf("Enter a string of symbols: ");
    scanf("%s", input);

    if (isAcceptedByDFA(&dfa, input)) {
        printf("The string is accepted by the DFA.\n");
    } else {
        printf("The string is not accepted by the DFA.\n");
    }

    return 0;
}
