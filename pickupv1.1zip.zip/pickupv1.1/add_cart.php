<?php

    include "connection.php";
    
    session_start();
    $username= $_SESSION['username'] ;
    $cus_id =  $_SESSION['customer_id'];

    $sql_cart_user = "SELECT * FROM carts WHERE customer_id = $cus_id";
    $result_carts=$conn->query($sql_cart_user);
    
    function name_items($id_para) {
      global $conn;
      $id_pro = "SELECT product_name FROM products where product_id = $id_para;";
      $result_pro=$conn->query($id_pro);
      if ($result_pro->num_rows > 0 ) {
         $produ = $result_pro->fetch_assoc();
         echo $produ['product_name'];
      }
    }
    function image_items($image_para) {
      global $conn;
      $id_pro = "SELECT product_image FROM products where product_id = $image_para;";
      $result_pro=$conn->query($id_pro);
      if ($result_pro->num_rows > 0 ) {
         $produ = $result_pro->fetch_assoc();
         echo $produ['product_image'];
      }
    }

    function seller_items($seller_para) {
      global $conn;
      $id_pro = "SELECT seller.seller_id FROM seller 
      inner join category on category.seller_id = seller.seller_id 
      inner join products on products.category_id = category.category_id
      where products.product_id =  $image_para;";
      $result_pro=$conn->query($id_pro);
      if ($result_pro->num_rows > 0 ) {
         $produ = $result_pro->fetch_assoc();
         echo $produ['seller_name'];
      }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>

<h1>Wellcome <?php echo  $username;?></h1>

     <button><a href="homepage.php">back to home pack</a></button>

  <table class="table" style="width: 1500px; margin: 100px; height: 150px;">
        <thead class="table-dark" >
          <tr>
            <th>Number cart</th>
            <th>Name</th>
            <th>Price</th>
            <th>seller</th>
            <th>QTY</th>
            <th>Image</th>
            <th>total price </th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          <?php
          if ($result_carts->num_rows > 0 ) {
            while( $row = $result_carts->fetch_assoc()){ 
              $cart_id = $row['cart_id'];
              $product_id = $row['product_id'];
              $qty =  $row['cart_qty']	;
              $price = $row['cart_price'];
          ?>
          <tr>
            <th><?php echo $row['cart_id']	; ?></th>
            <th><?php name_items( $row['product_id']	); ?></th>
            <th>$<?php echo $row['cart_price']	; ?></th>
            <th><?php seller_items( $row['product_id']	); ?></th>


            <th><?php echo $row['customer_id']	; ?></th>
            <th><?php echo $row['cart_qty']	; ?></th>
            <th><img src="<?php image_items( $row['product_id']	);  ?>" alt=""  width="50px" height="50px" ></th>
            <th><?php //echo $row['']	; ?></th>
            <th><?php //echo $row['']	; ?></th>
          </tr>

          <?php
           }
          }
          ?>
        </tbody>
  </table>
  <form method ="post">
          <button class="add" name="submit" >Add to cart</button>
    </form>
</body>
</html>
<?php
 
 if(isset($_POST['submit'])){
    $sql_cart_add = "SELECT * FROM `carts`where customer_id = $cus_id ;";
    $result_customer=$conn->query($sql_cart_add);
        $randomNumber = rand(1000, 9999);
        if( mysqli_num_rows($result_customer) > 0){
          while($customer = mysqli_fetch_assoc($result_customer)){ 
            $cart=$customer['cart_id'];
        $sql_insert_order = "INSERT INTO `order_items`(`orderItems_id`, `order_number`, `product_id`, `order_qty`, `order_price`, `customer_id`) 
                           VALUES ('','$randomNumber','$product_id','$qty','$price','$cus_id');";
        $qr_insert_order=$conn->query($sql_insert_order);

        }
      
      $total = "SELECT SUM(cart_price)  FROM carts WHERE customer_id = $cus_id;";
      $result_price = mysqli_query($conn, $total);
      $row = mysqli_fetch_assoc($result_price);
      $total_price = $row['SUM(cart_price)'];
      $sql_order = "INSERT INTO `orders`(`order_id`, `order_price_total`, `order_number`) 
                VALUES ('','$total_price','$randomNumber')";
      $qr_order=$conn->query($sql_order);
      
      $sql_delete_cart = "DELETE FROM `carts` where customer_id = $cus_id ;";
      $result_delete = $conn->query($sql_delete_cart);
      echo "<script>alert('already');window.location='homepage.php'</script>";
          }
   
      


 }

?>