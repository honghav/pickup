<?php
    include "connection.php";
    session_start();
    $username= $_SESSION['username'] ;
    $cus_id =  $_SESSION['customer_id'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Document</title>
    <style>
                
        .shop_card img{
            margin-top: 5px; 
            border-radius:5px;
            width: 300px;
            height: 300px; 
        }
       
        .scrollx {
            display: flex;
            flex-wrap: wrap;
            gap: 16px; /* space between items */
            width: 1920px;
            height: 520px;
        }
        .shop_card {
            flex: 1 1 calc(33.333% - 16px); /* 3 shop_cards per row with spacing */
            box-sizing: border-box;
            border: 1px solid #ddd;
            padding: 16px;
            text-align: center;
            width: 400px;
            background-color: rgb(236, 236, 236); 
            height: 500px;
        }
        @media (max-width: 768px) {
            .shop_card {
                flex: 1 1 calc(50% - 16px); /* 2 shop_cards per row on smaller screens */
            }
        }
        @media (max-width: 480px) {
            .shop_card {
                flex: 1 1 100%; /* 1 item per row on small screens */
            }
        }

        *{
                padding: 0;
                margin: 0;
                box-sizing: border-box;
                font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
                color: black;
            }

            html{
                font-size: 62.5%;
            }

            main{
                max-width: 1500px;
                width: 95%;
                margin: 30px auto;
                display: flex;
                flex-wrap: wrap;
                justify-content: space-between;
                margin: auto;
            }

            main .card{
                max-width: 300px;
                flex: 1 1 210px;
                text-align: center;
                height: 420px;
                border: 1px solid lightgray;
                margin: 20px;
            }

            main .card .image{
                height: 50%;
                margin-bottom: 20px;
            }

            main .card .image img{
                width: 100%;
                height: 100%;
                object-fit: cover;
            }

            main .card .caption{
                padding-left: 1em;
                text-align: left;
                line-height: 3em;
                height: 25%;
            }

            main .card .caption p{
                font-size: 1.5rem;
            }

            del{
                text-decoration: line-through;
            }

            main .card .caption .rate{
                display: flex;
            }

            main .card .caption .rate i{
                color: gold;
                margin-left: 2px;
            }

            main .card a{
                width: 50%;
            }

            main .card button{
                border: 2px solid black;
                padding: 1em;
                width: 80%;
                cursor: pointer;
                margin-top: 2em;
                font-weight: bold;
                position: relative;
            }

            main .card button:before{
                content: "";
                position: absolute;
                top: 0;
                left: 0;
                bottom: 0;
                width: 0;
                background-color: black;
                transition: all .5s;
                margin: 0;
            }

            main .card button::after{
                content: "";
                position: absolute;
                top: 0;
                right: 0;
                bottom: 0;
                width: 0;
                background-color: black;
                transition: all .5s;
            }

            main .card button:hover::before{
                width: 30%;
            }

            main .card button:hover::after{
                width: 30%;
            }

      


    </style>
    
</head>
<body>
    <div class="navbar">
        <div class="sitting">
            <img src="image/sitting.png" alt="" height="75px" width="75px">
        </div>
        <div class="nav_right">
            <img src="image/logo.png" alt="none" height="75px" width="250px" >
        </div>

        <div class="search">
            
                <div class="button_page">
                    <img src="image/icon2.png" alt="" width="50px" height="50px">
                    <div class="form_search" >
                        <form> 
                            <input type="text" placeholder="Seacrh......">
                        </form>
                    
                </div>
            </div>
        </div>

        <div class="all_button_nav_left">
            <div class="nav_left">
                <div class="button_page">
                    <img src="image/icon1.png" alt="" width="50px" height="50px">
                    <div class="text_button" >
                        <p>Home</p>
                    </div>
                </div>
            </div>
           
            <div class="nav_left">
                <div class="button_page">
                    <img src="image/nav1.png" alt="" width="50px" height="50px">
                    <div class="text_button" >
                        <p>Wellat</p>
                    </div>
                </div>
            </div>
    
            <div class="nav_left">
                <div class="button_page">
                    <img src="image/nav2.png" alt="" width="50px" height="50px">
                    <div class="text_button" >
                        <p>History</p>
                    </div>
                </div>
            </div>

            <div class="nav_left">
                <div class="button_page">
                    <img src="image/profile.png" alt="" width="50px" height="50px">
                    <div class="text_button" >
                        <p>Profile</p>
                    </div>
                </div>
            </div>

        </div>

    </div>
            <button><a href="add_cart.php">Cart</a></button>
    <div class="banner">
        <div class="banner_right">
            <img src="image/banner2.jpg" alt="" width="100%" height="100%">
        </div>
        <div class="banner_left">
            <img src="image/banner2.jpg" alt="" width="100%" height="100%">
        </div>
    </div>

    <h1>ហាងល្បីនៅទីនេះ...</h1>
    <div class="scrollx">
        <?php
        $logo_seller = "SELECT * from seller ";
        $result_logo_seller=$conn->query($logo_seller);
        if ($result_logo_seller->num_rows > 0 ) {
             while( $row = $result_logo_seller->fetch_assoc()){ 
            ?>
            <div class="shop_card" >
            <?php   
                echo  "<img src='".$row['seller_image']."' alt='none'";
            ?>
            <!-- <img src="image/shop3.jpeg" alt="" width="90%" height="60%" style="margin-top: 5px; border-radius:5px ;"> -->
            <div class="imfomation" style="" >
            <h2><?php echo $row['seller_name'];?></h2>
            <h3>Type of shop <?php echo $row['seller_type'];?></h3>
            <h5>Address <?php echo $row['seller_address'];?></h5>
            <h5>open: 24h</h5>
           </div>
        </div>
       
        <?php } } ?>
    </div> 
    
<h1>មុខម្ហូបពេញនិយមបំផុត...</h1>

    <main>
       <?php
        $sql_product = " SELECT * FROM category inner join products on category.category_id = products.category_id inner join seller on category.seller_id = seller.seller_id ;";
        $result_sql_product = $conn->query($sql_product);
        if ($result_sql_product->num_rows > 0) {
            while ($row = $result_sql_product->fetch_assoc()) {
                ?>
       <div class="card">
           <div class="image">
               <img src="<?php echo $row["product_image"]; ?>" alt="">
           </div>
           <div class="caption">
               <p class="rate">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
               </p>
               <p class="product_name"><?php  echo $row["product_name"];  ?></p>
               <p class="price"><b>$<?php echo $row["product_price"]; ?></b></p>
               <p class="discount"><b><del>$<?php echo $row["seller_name"]; ?></del></b></p>
           </div>
           <button class="add" data-id="<?php echo $row["product_id"];  ?>"><a href="view_product.php?id=<?php echo  $row["product_id"];  ?>">Add to cart</a></button>

       </div>
       <?php
            }
          }
     ?>
   </main>


   
</body>
</html>
