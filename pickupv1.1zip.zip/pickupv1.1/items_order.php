<?php
    include "connection.php";

    session_start();
    $username= $_SESSION['username'] ;
    $cus_id =  $_SESSION['customer_id'];

   
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<h1>Wellcome <?php echo  $username;?></h1>

<button><a href="homepage.php">back to home pack</a></button>

<table class="table" style="width: 1500px; margin: 100px; height: 150px;">
   <thead class="table-dark" >
     <tr>
       <th>Number order</th>
       <th>Name</th>
       <th>Price</th>
       <th>total price</th>
       <th>QTY</th>
       <th>Image</th>
       <th>total price </th>
       <th>customer</th>
       <th>Delete</th>
     </tr>
   </thead>
   <tbody>
     <?php
        $sql_order_items = "SELECT * FROM order_items 
        INNER JOIN carts ON carts.cart_id = order_items.cart_id 
        INNER JOIN products ON products.product_id = carts.product_id  
        WHERE carts.customer_id = $cus_id;";
        $result_orders=$conn->query($sql_order_items);
        if ($result_orders->num_rows > 0 ) {
            while( $row = $result_orders->fetch_assoc()){ 
     
     ?>
     <tr>
       <th><?php echo $row['order_number']	; ?></th>
       <th><?php echo$row['product_name']; ?></th>
       <th>$<?php echo $row['product_price']	; ?></th>
       <th>$<?php echo $row['cart_price']	; ?></th>
       <th><?php echo $row['cart_qty']	; ?></th>
       <th><img src="<?php echo$row['product_image'];  ?>" alt=""  width="50px" height="50px" ></th>
       
       <th><?php echo $row['customer_id']	; ?></th>
       <th><?php// echo $row['']	; ?></th>
     </tr>

     <?php
            }
        }
     ?>
   </tbody>
</table>

<form method ="post">
          <button class="add" name="submit" >Add to cart</button>
</form>
</body>
</html>
