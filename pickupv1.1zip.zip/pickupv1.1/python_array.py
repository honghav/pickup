# print_array.py
array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
columns = 3
i = 0
while i < len(array):
    print(' '.join(map(str, array[i:i + columns])))
    i += columns
