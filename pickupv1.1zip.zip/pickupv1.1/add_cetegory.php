<?php
    include "connection.php";
    session_start();
    $seller_id = $_SESSION['seller_id'];
    $seller_name =  $_SESSION['seller_name'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Form - GET Method</title>
</head>
<body>

    <h2>Welcome too <?php echo $seller_name ; ?></h2>
    <button><a href="shop_dashbord.php">go back</a></button>
    <form  method="get">
        <label for="text1">Name Of category:</label>
        <input type="text" id="text1" name="name"><br><br>
        <label for="text2">Image of category </label>
        <input type="text" id="text2" name="image"><br><br>
        <input type="submit" value="Submit " name ="submit">
    </form>
</body>
</html>

<?php
         if(!empty(isset($_GET['submit']))){
            $name = $_GET['name'];
            $image = $_GET['image'];
            if(!empty(trim($name))){ 
                $input = "INSERT INTO 
                `category`( `category_name`, `category_image`, `seller_id`) 
                VALUES ('$name','$image','$seller_id')";
                 if ($conn->query($input) === TRUE) {
                    echo "<script>alert('already');window.location='dashbord_seller.php'</script>";
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }else{
                echo"NOO";
             }
         }

?>